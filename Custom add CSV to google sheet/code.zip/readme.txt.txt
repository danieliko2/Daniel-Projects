How to execute:

1 - Upload the CSV file to google drive,
2 - Open the file in google sheets,
3 - go to Extentions > Apps Script,
4 - copy the contents of code.gs to the script.
5 - run the script.

for any questions,
feel free to message me - fiverr.com/users/danieliko2/

cheers,
daniel