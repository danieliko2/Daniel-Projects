Google Docs Generation App

This code generates google documents using a doc template and a sheet.
The main Spreadsheet ID is '1OirCGjopUu81qrvqJnyIhhi-RIzKfdI07yrge1n0EiU'.

Inside the Spreadsheet:

 -- Dashboard: --

 Generate Docs button - Runs the code script.
 Company - the company name - connected to the Data sheet for the company's root folder.
 Sheet - the sheet from which the data is taken from. Please make sure all the sheets are the same design as 'RS NAIL' !!
 Prodcut name - the name that will be inserted to the generated documents.
 Color Column - the column from where the color name and image will be taken (please make sure every color cell and image cell in every selected row is populated. empty cells can cause errors!)
 Rows - the rows in the sheet that will be generated (syntax: {'5' - will generate a row# 5, {'2-5' - will generate rows 2-5}, {'2,4,5' - will generate rows 2,4,5})
        please make sure the syntax is like the examples.
 Document Version - the version of the generated docs. if a folder with this version exists, the output will be generated in the folder, else it will generate a new folder for the output.
 templateID - the ID of the template for the script. If you change the ID, please make sure to follow the same template design (feel free to contact me for help with this).

-- Data --

Company names with their Root Folders.


If there is any bugs/errors/requests, feel free to contact me at fiverr.comn/danieliko2

Cheers,
Daniel :)

